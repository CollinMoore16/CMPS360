package main

import (
	"fmt"
)

func main() {
	// Asks for your name
	fmt.Print("What is your name? ")
	var name string
	fmt.Scanln(&name)

	// Asks for your age
	fmt.Print("How old are you? ")
	var age int
	fmt.Scanln(&age)

	// adds 10 years to your current age
	ageAfter10Years := age + 10

	// Prints greeting and shows the age calculation
	fmt.Printf("Hello, %s! In 10 years, you will be %d years old.\n", name, ageAfter10Years)
}
